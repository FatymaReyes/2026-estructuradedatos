using System;

class Program
{
    static int Factorial(int n)
    {
        if (n == 0 || n == 1)
        {
            return 1;
        }

        return n * Factorial(n - 1);
    }

    static void Main()
    {
        int resultado = Factorial(4);
        Console.WriteLine($"El factorial de 5 es: {resultado}"); // Salida: 120
    }
}