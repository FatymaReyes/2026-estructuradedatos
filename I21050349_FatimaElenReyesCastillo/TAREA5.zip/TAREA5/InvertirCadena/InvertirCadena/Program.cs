using System;

class Program
{
    static string InvertirCadena(string texto)
    {
        // Caso base: si la cadena es nula, vac�a o de un solo car�cter
        if (string.IsNullOrEmpty(texto) || texto.Length <= 1)
        {
            return texto;
        }

        // Caso recursivo: el �ltimo car�cter + la inversi�n de la cadena sin el �ltimo
        char ultimoCaracter = texto[texto.Length - 1];
        string restoCadena = texto.Substring(0, texto.Length - 1);

        return ultimoCaracter + InvertirCadena(restoCadena);
    }

    static void Main()
    {
        string palabra = "recursividad";
        string invertida = InvertirCadena(palabra);
        Console.WriteLine($"La palabra '{palabra}' invertida es: '{invertida}'"); // Salida: 'dadivisrucer'
    }
}