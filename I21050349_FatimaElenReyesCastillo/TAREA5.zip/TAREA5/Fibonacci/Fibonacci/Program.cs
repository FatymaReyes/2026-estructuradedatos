using System;

class Program
{
    static int Fibonacci(int n)
    {
        // Casos base
        if (n == 0) return 0;
        if (n == 1) return 1;

        // Caso recursivo: suma de los dos t�rminos anteriores
        return Fibonacci(n - 1) + Fibonacci(n - 2);
    }

    static void Main()
    {
        int resultado = Fibonacci(6);
        Console.WriteLine($"El t�rmino 6 de la serie de Fibonacci es: {resultado}"); // Salida: 8
    }
}